 LOAD DATA LOCAL INFILE "C:\\data.csv"
 INTO TABLE ndap.FarmersInsuranceData
 FIELDS TERMINATED BY ','  
 ENCLOSED BY '"'          
 LINES TERMINATED BY '\n' 
 IGNORE 1 ROWS;
 
 select distinct percentageMaleFarmersCovered from ndap.FarmersInsuranceData order by 1 desc;
 select srcStateName from ndap.FarmersInsuranceData ;
 -- 2. RetrieveTotalFarmersCoveredandSumInsuredfor  each  state,  ordered  descending  byTotalFarmersCovered;
 select farm.srcStateName,farm.TotalFarmersCovered,farm.SumInsured from (select distinct srcStateName,TotalFarmersCovered,SumInsured,
 ROW_NUMBER() OVER (PARTITION BY srcStateName ORDER BY TotalFarmersCovered) as rn
 from ndap.FarmersInsuranceData) farm ;
 
 -- 3. Retrieve records whereYearis 2020.; 
 select * from ndap.FarmersInsuranceData where REGEXP_substr(year_, '[0-9]{4}') = 2020;
 -- 4.Retrieve records whereTotalPopulationRural > 10,00,000andsrcStateName = "HIMACHALPRADESH".;
 select * from ndap.FarmersInsuranceData where TotalPopulationRural > 1000000 and srcStateName = 'HIMACHAL PRADESH';
 
 
 -- 5. Retrieve thesrcStateName,srcDistrictName, and the sum ofFarmersPremiumAmountfor eachdistrict in the year 2018, ordered byFarmersPremiumAmountin ascending order.;
 select srcStateName,srcDistrictName, sum(FarmersPremiumAmount) over(partition by srcDistrictName order by FarmersPremiumAmount ) as FarmersPremiumAmount from ndap.FarmersInsuranceData where REGEXP_substr(year_, '[0-9]{4}') = 2018;
 
 -- 6. Retrieve the total number of farmers covered and the sum of the gross premium amount to bepaid for each state where the insured land area is greater than 5.0 for the year 2018.;
 select TotalFarmersCovered,sum(GrossPremiumAmountToBePaid) over (partition by srcdistrictname) as GrossPremiumAmountToBePaid   from ndap.FarmersInsuranceData where REGEXP_substr(year_, '[0-9]{4}') = 2018 and insuredlandarea > 5.0;
 
 -- 7. Calculate averageInsuredLandAreafor each year;
 select year_,avg(InsuredLandArea) from ndap.FarmersInsuranceData group by year_; 
 
 -- 8. CalculateTotalFarmersCoveredfor each district whereInsuranceUnits > 0.;
 select srcdistrictname,TotalFarmersCovered from ndap.FarmersInsuranceData where InsuranceUnits > 0 group by srcdistrictname,TotalFarmersCovered; 
 
 -- 9. Calculate total premiums andTotalFarmersCoveredfor each state where totalSumInsured >5,00,000INR;
 select srcstatename,sum(TotalFarmersCovered),sum(farmerspremiumamount) from ndap.FarmersInsuranceData group by srcstatename having sum(sumInsured) > 500000; 
 
 IV.  Sorting Data (ORDER BY) [10 marks]
-- 10. Retrieve the top 5 districts with the highest total population in 2020.;
select pop.TotalPopulation from (select TotalPopulation,row_number() over(order by TotalPopulation desc) as rnk from ndap.FarmersInsuranceData where YearCode = 2020) pop where pop.rnk < 6;

-- 11. RetrievesrcStateName,srcDistrictName, andSumInsuredfor the 10 districts with lowestnon-zero farmers’ premium amount, ordered by insured sum and premium amount.;
 select pop.srcStateName,pop.srcDistrictName,pop.SumInsured from (select srcStateName,srcDistrictName,SumInsured,row_number() over(order by SumInsured,FarmersPremiumAmount asc) as rnk from ndap.FarmersInsuranceData 
 where FarmersPremiumAmount != 0) pop where pop.rnk < 11;
 
 -- 12. Retrieve top 3 states for each year with highest insured farmers to total population ratio, orderedby the ratio.;
 select pop.srcStateName,pop.srcDistrictName,pop.SumInsured from (select srcStateName,srcDistrictName,SumInsured,row_number() over(partition by year_ order by SumInsured,FarmersPremiumAmount asc) as rnk from ndap.FarmersInsuranceData 
 where FarmersPremiumAmount != 0) pop where pop.rnk < 11;
 select srcStateName,srcDistrictName,SumInsured,row_number() over(partition by year_ order by SumInsured,FarmersPremiumAmount asc) as rnk from ndap.FarmersInsuranceData;
 select sumInsured,TotalPopulation, from ndap.FarmersInsuranceData;
 
 SELECT YearCode, srcStateName, SumInsured, TotalPopulation,
       (SumInsured / TotalPopulation) AS insured_ratio
FROM (
    SELECT YearCode, srcStateName, SumInsured, TotalPopulation,
           ROW_NUMBER() OVER (PARTITION BY YearCode ORDER BY (SumInsured / TotalPopulation) DESC) AS rnk
    FROM ndap.FarmersInsuranceData
) ranked
WHERE rnk <= 3
ORDER BY YearCode, insured_ratio DESC;

-- 	Q13. 	Create StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.;
select substr(srcStateName,1,3) from ndap.FarmersInsuranceData;

-- 14. RetrievesrcDistrictNamewhere the district name starts with"B".;
select srcDistrictName from ndap.FarmersInsuranceData where srcDistrictName like 'B%';

-- 15. RetrievesrcStateNameandsrcDistrictNamewhere district name ends with"pur".;
select srcStateName,srcDistrictName from ndap.FarmersInsuranceData where srcDistrictName like '%pur';

VI.  Joins [14 marks]
-- 16. INNER JOINsrcStateNameandsrcDistrictNameto retrieve the aggregated farmers’ premiumamount for districts where the Insurance units for an individual year are greater than 10.;
SELECT srcStateName,srcDistrictName,srcYear,
    SUM(FarmersPremiumAmount) AS TotalFarmersPremiumAmount FROM  ndap.FarmersInsuranceData WHERE InsuranceUnits > 10 GROUP BY srcStateName, srcDistrictName, srcYear;
    
-- 17. RetrievesrcStateName,srcDistrictName,Year,TotalPopulationfor each district and thethe highest recorded farmers premium amount for that district over all available years. 
Returnonly those districts where the highest amount exceeds 20 crores.;
SELECT A.srcStateName,A.srcDistrictName,A.srcYear AS Year_,A.TotalPopulation,A.FarmersPremiumAmount AS HighestFarmersPremiumAmount FROM NDAP.FarmersInsuranceData A
INNER JOIN(SELECT srcStateName,srcDistrictName, MAX(FarmersPremiumAmount) AS MaxPremium FROM ndap.FarmersInsuranceData GROUP BY srcStateName, srcDistrictName)P
ON A.srcStateName = P.srcStateName AND A.srcDistrictName = P.srcDistrictName AND A.FarmersPremiumAmount = P.MaxPremium
WHERE P.MaxPremium > 2000;


-- 18. Perform a LEFT JOIN to combine the total population statistics with the farmers’ data for eachdistrict and state. 
Return the total premium amount and the average population count for eachdistrict aggregated over the years, where the total premium amount is greater than 100 crores.
Sort the results by total farmers’ premium amount, highest first.;
SELECT srcStateName,srcDistrictName,SUM(FarmersPremiumAmount) AS TotalPremiumAmount,AVG(TotalPopulation) AS AveragePopulation FROM ndap.FarmersInsuranceData
GROUP BY srcStateName,srcDistrictName
HAVING SUM(FarmersPremiumAmount) > 10000
ORDER BY TotalPremiumAmount DESC;

-- Q19.	Write a query to find the districts (srcDistrictName) where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.;
SELECT distinct (srcDistrictName) FROM ndap.FarmersInsuranceData where TotalFarmersCovered > (select avg(TotalFarmersCovered) from ndap.FarmersInsuranceData);

-- Q20.	Write a query to find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.;
SELECT srcStateName,SumInsured FROM ndap.FarmersInsuranceData where SumInsured > 
(select sumInsured from ndap.FarmersInsuranceData where FarmersPremiumAmount = (select max(FarmersPremiumAmount) from ndap.FarmersInsuranceData));--275019

-- Q21.	Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.;
select srcDistrictName from ndap.FarmersInsuranceData where  FarmersPremiumAmount > 
(select avg(FarmersPremiumAmount) from ndap.FarmersInsuranceData where TotalPopulation = (select max(TotalPopulation) from ndap.FarmersInsuranceData));

-- Q22.	Use the ROW_NUMBER() function to assign a row number to each record in the dataset ordered by total farmers covered in descending order.;
select row_number() over(order by  a.TotalFarmersCovered desc) as rnk,a.* from ndap.FarmersInsuranceData a;

-- Q23.	Use the RANK() function to rank the districts (srcDistrictName) based on the SumInsured (descending) and partition by alphabetical srcStateName.;
select rank() over(partition by srcStateName order by  a.SumInsured desc) as rnk,a.srcDistrictName from ndap.FarmersInsuranceData a;

-- 	Q24.	Use the SUM() window function to calculate a cumulative sum of FarmersPremiumAmount for each district (srcDistrictName), ordered ascending by the srcYear, partitioned by srcStateName.;
select srcDistrictName,sum(a.FarmersPremiumAmount) over(partition by srcStateName order by  a.srcYear asc) as rnk from ndap.FarmersInsuranceData a;

-- 	Q25.	Create a table 'districts' with DistrictCode as the primary key and columns for DistrictName and StateCode. 
-- 		Create another table 'states' with StateCode as primary key and column for StateName.

create table ndap.districts
(DistrictCode INT primary key,
DistrictName VARCHAR(255),
StateCode INT
);

create table ndap.states
(StateCode INT  primary key,
StateName VARCHAR(255)
);


-- Q26.	Add a foreign key constraint to the districts table that references the StateCode column from a states table.
ALTER TABLE ndap.districts
ADD CONSTRAINT stCode_fk foreign key(StateCode) references states(StateCode);

-- 	Q27.	Update the FarmersPremiumAmount to 500.0 for the record where rowID is 1.
update ndap.FarmersInsuranceData
set FarmersPremiumAmount = 500.0 where rowID = 1;
commit;

-- 	Q28.	Update the Year to '2021' for all records where srcStateName is 'HIMACHAL PRADESH'.
update ndap.FarmersInsuranceData
set year_ = 2011 where srcStateName = 'HIMACHAL PRADESH';
commit;

-- 	Q29.	Delete all records where the TotalFarmersCovered is less than 10000 and Year is 2020.
delete from ndap.FarmersInsuranceData where TotalFarmersCovered < 10000 and year_ = 2020;
commit;